using CurrencyChange.BL;

namespace CurrencyChange.Test
{
    public class CurrencyChangeTests
    {
        [Test]
        public void CurrencyChangeSuccess()
        {
            Currency curr = new Currency();

            curr.GivenAmount = 50;
            curr.PurchaseAmount = 30;
            var change = curr.GetChangeToDisplay(out string error);

            Assert.IsTrue(!string.IsNullOrEmpty(change) && string.IsNullOrEmpty(error));
        }

        [Test]
        public void CurrencyChangeFailWithError()
        {
            Currency curr = new Currency();

            curr.GivenAmount = 20;
            curr.PurchaseAmount = 30;
            var change = curr.GetChangeToDisplay(out string error);

            Assert.IsTrue(error.Contains("Purchase Amount Greater than Given Amount"));
        }
        [Test]
        public void CurrencyChangeWithSameAmount()
        {
            Currency curr = new Currency();

            curr.GivenAmount = 50;
            curr.PurchaseAmount = 50;
            var change = curr.GetChangeToDisplay(out string error);

            Assert.IsTrue(error.Contains("No balance amount to display"));
        }
    }
}