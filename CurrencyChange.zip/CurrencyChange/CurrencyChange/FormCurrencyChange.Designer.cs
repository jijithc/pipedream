﻿namespace CurrencyChange
{
    partial class FormCurrencyChange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtGivenAmount = new System.Windows.Forms.TextBox();
            this.txtPurchaseAmount = new System.Windows.Forms.TextBox();
            this.txtCurrChange = new System.Windows.Forms.RichTextBox();
            this.btnChange = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblErrorMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtGivenAmount
            // 
            this.txtGivenAmount.Location = new System.Drawing.Point(415, 54);
            this.txtGivenAmount.Name = "txtGivenAmount";
            this.txtGivenAmount.Size = new System.Drawing.Size(172, 27);
            this.txtGivenAmount.TabIndex = 0;
            this.txtGivenAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGivenAmount_KeyPress);
            // 
            // txtPurchaseAmount
            // 
            this.txtPurchaseAmount.Location = new System.Drawing.Point(415, 114);
            this.txtPurchaseAmount.Name = "txtPurchaseAmount";
            this.txtPurchaseAmount.Size = new System.Drawing.Size(172, 27);
            this.txtPurchaseAmount.TabIndex = 2;
            this.txtPurchaseAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPurchaseAmount_KeyPress);
            // 
            // txtCurrChange
            // 
            this.txtCurrChange.Location = new System.Drawing.Point(415, 217);
            this.txtCurrChange.Name = "txtCurrChange";
            this.txtCurrChange.Size = new System.Drawing.Size(157, 182);
            this.txtCurrChange.TabIndex = 3;
            this.txtCurrChange.Text = "";
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(415, 163);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(101, 29);
            this.btnChange.TabIndex = 4;
            this.btnChange.Text = "Process";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(250, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Given Amount";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(253, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Purchased Amount";
            // 
            // lblErrorMsg
            // 
            this.lblErrorMsg.AutoSize = true;
            this.lblErrorMsg.ForeColor = System.Drawing.Color.Red;
            this.lblErrorMsg.Location = new System.Drawing.Point(413, 196);
            this.lblErrorMsg.Name = "lblErrorMsg";
            this.lblErrorMsg.Size = new System.Drawing.Size(0, 20);
            this.lblErrorMsg.TabIndex = 7;
            // 
            // FormCurrencyChange
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblErrorMsg);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.txtCurrChange);
            this.Controls.Add(this.txtPurchaseAmount);
            this.Controls.Add(this.txtGivenAmount);
            this.Name = "FormCurrencyChange";
            this.Text = "Currency Change";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtGivenAmount;
        private TextBox txtPurchaseAmount;
        private RichTextBox txtCurrChange;
        private Button btnChange;
        private Label label1;
        private Label label2;
        private Label lblErrorMsg;
    }
}