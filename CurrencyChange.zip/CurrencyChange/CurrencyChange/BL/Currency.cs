﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyChange.BL
{
    public class Currency
    {
        public decimal GivenAmount { get; set; }
        public decimal PurchaseAmount { get; set; }

        private decimal[] lstDenom = { 500, 200, 100, 50, 20, 10, 5, 2, 1, .5m, .2m, .1m, .05m, .02m, 01m };

        public List<KeyValuePair<decimal, int>> DenomCount;
        public Currency()
        {
            this.DenomCount = new List<KeyValuePair<decimal, int>>();
        }

        public string GetChangeToDisplay(out string error)
        {
            try
            {
                error = string.Empty;
                if (Validate(out error))
                {
                    this.GetCurrencyChange();
                    return this.GetChangeAsString();
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return string.Empty;
        }

        public bool Validate(out string error)
        {
            error = string.Empty;
            if (this.GivenAmount < this.PurchaseAmount)
            {
                error = "Purchase Amount Greater than Given Amount";

                return false;
            }
            else if(this.GivenAmount == this.PurchaseAmount)
            {
                error = "No balance amount to display";

                return false;
            }

            return true;
        }

        private void GetCurrencyChange()
        {
            decimal balamount = this.GivenAmount - this.PurchaseAmount;

            foreach(decimal denom in lstDenom)
            {
                int notecount = (int)(balamount/denom);

                if (notecount > 0)
                {
                    this.DenomCount.Add(new KeyValuePair<decimal, int>(denom, notecount));
                }

                balamount = balamount % denom;

                if (balamount <= 0)
                {
                    return;
                }
            }
        }

        private string GetChangeAsString()
        {
            StringBuilder ChangeString = new StringBuilder();

            ChangeString.AppendLine("Your change is:");
            foreach(var keyval in this.DenomCount)
            {
                string denomcount = string.Format(@"{0} x {1}", keyval.Value, this.GetCurrWithSymbol(keyval.Key));
                ChangeString.Append(denomcount); 
                ChangeString.AppendLine();
            }

            return ChangeString.ToString();
        }

        private string GetCurrWithSymbol(decimal curr)
        {
            if (curr >= 1)
            {
                return string.Format(@"£{0}", curr.ToString());
            }
            else
            {
                return string.Format(@"{0}p",((int)(curr * 100)).ToString());
            }
        }
    }
}
